package com.example.mediaplayer;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int startTime = 0;
    int stopTime = 0;
    int forwardTime = 5000;
    int backwardTime = 5000;
    MediaPlayer mediaPlayer, mediaPlayernew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mediaPlayer = MediaPlayer.create(this, R.raw.game_of_thrones);
        mediaPlayernew = MediaPlayer.create(this, R.raw.game_of_thrones);
        TextView songtitle = findViewById(R.id.songname);
        songtitle.setText("GOT");

        Button play = findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Playing Song", Toast.LENGTH_LONG).show();
                mediaPlayer.start();
            }
        });

        Button pause = findViewById(R.id.pause);
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Pausing Song", Toast.LENGTH_LONG).show();
                mediaPlayer.pause();
            }
        });

        Button forward = findViewById(R.id.forward);
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentpos = mediaPlayer.getCurrentPosition();
                if((currentpos + forwardTime) <= (stopTime = mediaPlayer.getDuration())){
                    mediaPlayer.seekTo(currentpos + forwardTime);
                }
            }
        });

        Button rewind = findViewById(R.id.rewind);
        rewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentpos = mediaPlayer.getCurrentPosition();
                if((currentpos - backwardTime >= 0)){
                    mediaPlayer.seekTo(currentpos - backwardTime);
                }
            }
        });

        Button stop = findViewById(R.id.stop);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Stopping Song", Toast.LENGTH_LONG).show();
                mediaPlayer.stop();
                mediaPlayer = mediaPlayernew;
            }
        });

        Button restart = findViewById(R.id.restart);
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Restarting Song", Toast.LENGTH_LONG).show();
                mediaPlayer.seekTo(0);
                mediaPlayer.start();
            }
        });
    }
}